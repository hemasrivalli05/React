import './style.css'
import VideoContainer from './VideoContainer'

const App = () => {
  return (
    <>
    <VideoContainer/>
    </>
  )
}

export default App